
DROP PACKAGE BANKING_PROCS;

CREATE OR REPLACE PACKAGE BANKING_PROCS AS  

   PROCEDURE createBankLink(
	p_bic		VARCHAR2,
	p_bankname	VARCHAR2,
	p_linkname 	VARCHAR2,
	p_username	VARCHAR2,
	p_password	VARCHAR2,
	p_host		VARCHAR2,
	p_oracle_sid	VARCHAR2
   );   

   PROCEDURE withdraw ( p_value	  	NUMBER, p_iban		VARCHAR2, p_bic		VARCHAR2, p_callInTransfer BOOLEAN);
   
   PROCEDURE deposit (p_value		NUMBER, p_iban		VARCHAR2, p_bic		VARCHAR2, p_callInTransfer BOOLEAN);
   
   PROCEDURE transfer (
  	p_value			NUMBER,
	from_iban		VARCHAR2,
	from_bic		VARCHAR2,
	to_iban			VARCHAR2,
	to_bic			VARCHAR2
   );

END BANKING_PROCS;

CREATE OR REPLACE PACKAGE BODY BANKING_PROCS AS  
	PROCEDURE createBankLink(
	p_bic		VARCHAR2,
	p_bankname	VARCHAR2,
	p_linkname 	VARCHAR2,
	p_username	VARCHAR2,
	p_password	VARCHAR2,
	p_host		VARCHAR2, 
	p_oracle_sid	VARCHAR2) IS
   
	numberOfLinks Number;
	link_exists EXCEPTION;

   BEGIN
    -- check if linkname already exists
    SELECT Count(*) INTO numberOfLinks FROM user_db_links WHERE DB_LINK = p_linkname;
    IF (numberOfLinks > 0) THEN 
      RAISE link_exists;
    END IF;
    -- create database link here
    EXECUTE IMMEDIATE 'CREATE DATABASE LINK '|| p_linkname ||' CONNECT TO '|| p_username ||' IDENTIFIED BY '|| p_password ||' 
      USING ''(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)
			(HOST = '|| p_host ||' )(PORT = 1521))) (CONNECT_DATA = (SID = '|| p_oracle_sid ||')))''';
    -- store info in config table
    INSERT INTO bank_config VALUES (p_bic,p_bankname,'remote',p_linkname,p_username,p_password,p_host,p_oracle_sid);
   	EXCEPTION
      WHEN link_exists THEN raise_application_error(-20011,'Error in banking_proc.createDBLink: database link with same name already exists !!');
   END createBankLink;

   PROCEDURE withdraw(p_value NUMBER, p_iban	VARCHAR2, p_bic VARCHAR2, p_callInTransfer BOOLEAN) is
		unknown_account EXCEPTION;
		unknown_bank EXCEPTION;
		not_local_bic EXCEPTION;
		not_enough_money EXCEPTION;
		negative_value EXCEPTION;
		numberOfAccs Number;
		numberOfBanks Number;
		curBalance Number;
		loc VARCHAR2(100);
	BEGIN
		dbms_output.put_line('Starting withdraw...');
		SELECT Count(*) INTO numberOfAccs FROM account WHERE IBAN = p_iban;
		IF (numberOfAccs > 0) THEN 
			SELECT Count(*) INTO numberOfBanks FROM bank_config WHERE BIC = p_bic;
			IF (numberOfBanks > 0) THEN
				SELECT location INTO loc FROM bank_config WHERE BIC = p_bic;
				IF (loc='local') THEN
          IF (p_value >= 0) THEN
            SELECT Balance INTO curBalance FROM account WHERE IBAN = p_iban FOR UPDATE;
            curBalance := curBalance - p_value;
            IF (curBalance >= 0) THEN
              UPDATE account set Balance = curBalance where IBAN = p_iban;
              IF (p_callInTransfer=false) THEN
                COMMIT;
              END IF;
            ELSE
              RAISE not_enough_money;
            END IF;
          ELSE
            RAISE negative_value;
          END IF;
				ELSE
					RAISE not_local_bic;
				END IF;
			ELSE
				RAISE unknown_bank;
			END IF;
		ELSE
			RAISE unknown_account;
		END IF;
		EXCEPTION
			WHEN unknown_account THEN 
				raise_application_error(-20011,'Error in banking_proc.withdraw: Unknown account!!');
        ROLLBACK;
			WHEN unknown_bank THEN
				raise_application_error(-20011,'Error in banking_proc.withdraw: Unknown bank!!');
        ROLLBACK;
			WHEN not_local_bic THEN
				raise_application_error(-20011,'Error in banking_proc.withdraw: Not local BIC!!');
        ROLLBACK;
			WHEN not_enough_money THEN
				raise_application_error(-20011,'Error in banking_proc.withdraw: Not enough money!!');
				ROLLBACK;
      WHEN negative_value THEN
        raise_application_error(-20011,'Error in banking_proc.withdraw: Cannot withdraw negative value!!');
				ROLLBACK;
   END withdraw;

  PROCEDURE deposit (p_value NUMBER, p_iban VARCHAR2, p_bic VARCHAR2, p_callInTransfer BOOLEAN)  IS
		unknown_account EXCEPTION;
		unknown_bank EXCEPTION;
		negative_value EXCEPTION;
		numberOfAccs Number;
		numberOfBanks Number;
		curBalance Number;
	BEGIN
		dbms_output.put_line('Starting deposit...');
		SELECT Count(*) INTO numberOfAccs FROM account WHERE IBAN = p_iban;
		IF (numberOfAccs > 0) THEN 
			SELECT Count(*) INTO numberOfBanks FROM bank_config WHERE BIC = p_bic;
			IF (numberOfBanks > 0) THEN
        IF (p_value >= 0) THEN
          SELECT Balance INTO curBalance FROM account WHERE IBAN = p_iban FOR UPDATE;
          curBalance := curBalance + p_value;
          UPDATE account set Balance = curBalance where IBAN = p_iban;
          IF (p_callInTransfer=false) THEN
                COMMIT;
          END IF;
        ELSE
          RAISE negative_value;
        END IF;
			ELSE
				RAISE unknown_bank;
			END IF;
		ELSE
			RAISE unknown_account;
		END IF;
		EXCEPTION
			WHEN unknown_account THEN 
				raise_application_error(-20011,'Error in banking_proc.deposit: Unknown account!!');
        ROLLBACK;
			WHEN unknown_bank THEN
				raise_application_error(-20011,'Error in banking_proc.deposit: Unknown bank!!');
        ROLLBACK;
      WHEN negative_value THEN
        raise_application_error(-20011,'Error in banking_proc.deposit: Cannot deposit negative value!!');
        ROLLBACK;
   END deposit;

   PROCEDURE transfer (p_value NUMBER, from_iban VARCHAR2, from_bic VARCHAR2, to_iban VARCHAR2, to_bic VARCHAR2)  IS
    same_iban EXCEPTION;
    link_name VARCHAR2(100);
    call_in_transfer BOOLEAN := true;
   BEGIN
    IF (from_iban=to_iban) THEN
     RAISE same_iban;
    END IF;
    IF (from_bic=to_bic) THEN
      -- local transfer
      withdraw(p_value, from_iban, from_bic, true);
      deposit(p_value, to_iban, to_bic, true);
      COMMIT;
    ELSE
      -- remote deposit necessary
      SELECT linkname INTO link_name FROM bank_config where BIC = to_bic;
      withdraw(p_value, from_iban, from_bic, true);
      EXECUTE IMMEDIATE 'begin banking_procs.deposit@'|| link_name ||'(:1,:2,:3,:4); end;' USING p_value, to_iban, to_bic, call_in_transfer;
      COMMIT;
    END IF;
   EXCEPTION
    WHEN same_iban THEN
      raise_application_error(-20011,'Error in banking_proc.deposit: IBANs must differ!!');
      ROLLBACK;
   END transfer;

END BANKING_PROCS;