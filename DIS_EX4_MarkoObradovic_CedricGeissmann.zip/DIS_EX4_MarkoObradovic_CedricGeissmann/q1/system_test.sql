
-- IMPORTANT!!! THIS TEST IS MEANT TO BE RUN ON P7 BANK SERVER!!!!! 
-- The test on P6 would look almost identical except that the parameters would have to be adapted.

-- Preparations:
--  1) run banking_procs.sql on Bank Server P6 and P7
--  2) run db_schema_p6.sql on Bank Server P6 (creates Bank Links and Tables and inserts values into tables)
--  3) run db_schema_p7.sql on Bank Server P7 (creates Bank Links and Tables and inserts values into tables)

-- PLEASE READ!!!
-- Comment on BANKING_PROCS interface:
-- In order to assure atomicity during transfers we had to adapt the BANKING_PROCS interface you gave us as a starting point.
-- We just introduced a third parameter for the procedures "withdraw" and "deposit" in order to distinguish between "deposit"/"withdraw" calls
-- within the "transfer" procedure and calls of "deposit"/"withdraw" that happen decoupled. Within the "transfer" procedure "withdraw" and 
-- "deposit" are coupled and atomicity has to be assured. It has to be assured that "deposit" is not executed if "withdraw" fails and 
-- there is the need for a rollback. As well, the changes of "withdraw" have to be undone if "deposit" fails. Rollback Work is eminently 
-- important. Therefore, the third parameter is used to postpone the COMMIT of the "transfer" transaction until "withdraw" and "deposit" 
-- have finished their work successfully, otherwise atomicity cannot be assured. If we commit "withdraw" or "deposit" independently during 
-- a transfer it might happen that although one of these procedures has failed (e.g. unknown account or bank) the other one could be executed 
-- successfully. This would cause consistency problems. The data would no more be correct. 
-- Therefore, we introduced an additional parameter.

-- local withdraw: negative value test => expected: withdraw is aborted due to the negative value the procedure wants to withdraw => rollback
execute banking_procs.withdraw(-300,'CH5367A1','P7', false);
-- local withdraw: not enough money test => expected: withdraw is aborted and locks are released due to rollback
execute banking_procs.withdraw(1000000,'CH5367A1','P7', false);
-- local withdraw: unknown account test => expected: withdraw is aborted due to unknown account exception, leads to a rollback
execute banking_procs.withdraw(300, 'bla bla', 'P7', false);
-- local withdraw: unknown bank test => expected: withdraw is aborted due to unknown bank exception, leads to a rollback
execute banking_procs.withdraw(1,'CH5367A1','PX', false);
-- remote withdraw: not local bic test => expected: a remote withdraw is not possible. withdraw is aborted due to remote bic, leads to rollback.
    -- try to do a withdraw at P6 with bic P7, which is not local at P6
  execute banking_procs.withdraw@LinkToBankP6(1,'CH5887A1','P7', false); 
  -- try to do a withdraw at P7 with bic P6, which is not local at P7
  execute banking_procs.withdraw(1,'CH5367A1','P6', false);
  
-- local deposit: negative value test => expected: deposit is aborted due to the negative value the procedure wants to deposit, leads to rollback
execute banking_procs.deposit(-300,'CH5367A1','P7', false);
-- local deposit: unknown account test => expected: deposit is aborted due to unknown account exception, leads to a rollback
execute banking_procs.deposit(300, 'bla bla', 'P7', false);
-- local deposit: unknown bank test => expected: deposit is aborted due to unknown bank exception, leads to a rollback
execute banking_procs.deposit(1,'CH5367A1','PX', false);
-- remote deposit: not local bic test => expected: a remote deposit is possible
  -- try to do a deposit at P6 with bic P7, which is not local at P6
  execute banking_procs.deposit@LinkToBankP6(1,'CH5887A1','P7', false);
  -- try to do a deposit at P7 with bic P6, which is not local at P7
  execute banking_procs.deposit(200,'CH5367A1','P6', false);
  
-- atomicity check (all-or-nothing semantics):
-- transfer: not enough money => expected: withdraw is aborted and deposit is not executed, leads to rollback of txn
execute banking_procs.transfer(1000000,'CH5367A1','P7','CH5887A1','P6'); 
-- transfer: unknown account at P6 => expected: withdraw is not aborted but deposit will encounter an error. this leads to a rollback of txn
execute banking_procs.transfer(200,'CH5367A1','P7','bla bla','P6');

